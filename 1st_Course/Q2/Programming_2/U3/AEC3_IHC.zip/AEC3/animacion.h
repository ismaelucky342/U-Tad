#ifndef ANIMACION_H
#define ANIMACION_H
#include "mensaje.h"

void configurarAnimacion(int *velocidad, int *tamanioVentana);
void animarTexto(Mensaje mensaje, int velocidad, int tamanioVentana);

#endif
